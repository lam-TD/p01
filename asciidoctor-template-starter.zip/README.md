# AsciiDoctor Template Starter (Company Docs)

## What you get
- Opinionated folder structure for **templates**, **partials**, and **themes**
- Company-wide **attributes** you can override per document
- A brandable **PDF theme** and an **HTML CSS** file
- Reusable templates: PRD, SRS, ADR, Runbook, SOP, Policy
- Simple `build-html.sh` and `build-pdf.sh` scripts + `Makefile`

## Prerequisites
- Ruby + gems: `asciidoctor asciidoctor-pdf asciidoctor-kroki`
  ```bash
  gem install asciidoctor asciidoctor-pdf asciidoctor-kroki rouge
  ```
- **Fonts** for PDF: put `Noto Sans`, `Noto Serif`, `Noto Sans Mono` (or your fonts) into `theme/fonts/`.

## Build
```bash
./build/build-html.sh docs/examples/prd-example.adoc
./build/build-pdf.sh  docs/examples/prd-example.adoc
# or
make all
```

## Tips
- Global attributes: edit `config/attributes-company.adoc`
- Classification watermark (HTML): enabled via `config/docinfo.html`
- Diagrams: supported via Kroki blocks, e.g.:
  ```
  [plantuml]
  ----
  @startuml
  Alice -> Bob: Hello
  @enduml
  ----
  ```
